package com.timelessOrbit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimelessOrbitGameApplicationTests {

	@Test
	void contextLoads() {
	}

}
